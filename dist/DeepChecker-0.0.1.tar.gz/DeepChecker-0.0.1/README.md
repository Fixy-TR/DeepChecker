It is the tesing file with two sample classes named
class Message
    methods msg1()
class Show
    methods add(a,b), sub(a,b)
